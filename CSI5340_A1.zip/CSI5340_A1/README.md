# Assignment 1

Student Name: Alexandra Sklokin

Student Number: 300010511

This is my Assignment 1 submission.

## StochasticGradientDescent

Python noteboook for Stochastic Gradient Descent implementation.

## Results.ipynb

Python notebook for producing report graphs and tables.

## outputs.xlxs / outputs_weight_decay.xlxs

Excel sheet for performance of Stochastic Gradient Descent algorithm with and without Weight Decay. Displays E_in_bar, E_out_bar, and E_bias. 

## graphs / graphs_weight_decay

Folder containing output of Results.ipynb. Graphs of relationships between parameters and performance metrics.

## images

Folder contains images used in report.

## Report

Folder contains assignment report and report source code.
