# Assignment 3

Student Name: Alexandra Sklokin

Student Number: 300010511

This is my Assignment 3 submission.

## CNN_PGD.py

Python code for CNN model and PGD algorithm implementation.

## Experiments.ipynb

Python notebook utilizes CNN_PGD.py to obtain training and testing results. Also used to produce graphs and tables.

## Adversarial_Examples.ipynb

Python notebook utlized to produce examples of targeted and untargeted PGD.

## Morgue_Implementation.ipynb

Old python noteboook used during development stage of CNN_PGD.py. Need not be referenced.

## output

Folder contains outputs from python notebookes (stats, graphs, and perturbation images)

## data

Folder containing original MNIST dataset.

## report

Folder contains assignment report and report source code.
