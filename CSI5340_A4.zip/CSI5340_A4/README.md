# Assignment 4

Student Name: Alexandra Sklokin

Student Number: 300010511

This is my Assignment 4 submission.

## /code

Folder contains all .ipynb files which implement VAE/GAN/WGAN for MNIST/CIFAR10.

## output

Folder contains outputs from python notebookes (stats, graphs, figures, etc.)

## report

Folder contains assignment report and report source code.

